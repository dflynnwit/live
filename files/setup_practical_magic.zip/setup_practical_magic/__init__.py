from IPython import utils
from IPython.display import display, HTML, Markdown

import os

# load libraries
import numpy as np
import scipy as sci
import sympy as sym
import matplotlib.pyplot as plt
import seaborn as sns
sns.set(style="darkgrid")

from pylab import *

__version__ = 23.1
   
def apply_extra_css_styling(show_message=False):  
    """Update default styles using custom.css (from ipython profile) and then extra.css."""
    
    custom_css = ""
    
    extra_css = open(os.path.join('setup_practical_magic', 'extra.css'), 'r').read()
 
    styles = "<style>\n%s\n\n%s</style>" % (custom_css, extra_css)
    if show_message:
        styles += 'Python practical setup tools version %s. See <a target="_blank" href="https://setu-discretemathematics.github.io/live/00-Module_Introduction/33-Python_Practicals">https://setu-discretemathematics.github.io/live/00-Module_Introduction/33-Python_Practicals</a>' % __version__
    return HTML(styles)

def setup_practical(notebook_state, require_id=True):
    
    student_id = notebook_state['student_id'] if 'student_id' in notebook_state else 'W00000000'

    if require_id and '00000000' in student_id:
        js = "<script>alert('Make sure to specify your student ID and your name in the Setup section of this notebook.');</script>"
        display(HTML(js))

    #HTML("Ver " + str(__version__) + ' <a href="http://example.com">link</a>')
    #print ("Ver", __version__)

    # finally setup styles
    return apply_extra_css_styling(True)

from .logic import *